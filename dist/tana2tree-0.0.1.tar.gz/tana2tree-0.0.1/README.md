# Tanagra Parser
This packages parses a Tanagra html description into usable formats.

More information to come...